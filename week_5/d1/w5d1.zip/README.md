# Introduction to SQL

- Use DB Browswer to connect to existing databases
- Create a new database and tables
- Execute SQL queries
- Export the results of queries
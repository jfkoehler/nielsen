# Programming with Python I

![](https://imgs.xkcd.com/comics/python_environment.png)

**OBJECTIVES**

- Launch Jupyter Notebooks and Lab
- Differentiate between Python scripts and Jupyter notebooks
- Use code and markdown cells in Jupyter notebooks
- Understand different data types and variable assignment in Python
- Understand and use forced coersion of types in Python
- Use built-in functions in Python and navigate documentation
- Understand libraries with Python
- Use integers, strings, tuples, lists, and dictionaries

def gdp_min(dataframe):
    return dataframe['gdpPercap_1952'].min()